import React from 'react'

const Header = () => {
  return (
    <div className='font-bold h-[80px] bg-white sticky top-0'>
      


    </div>
  )
}

export default Header