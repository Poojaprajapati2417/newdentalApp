import React, { useEffect, useState } from 'react'
import "./../../styles/view-profile.css"
import axios from 'axios'
import Swal from 'sweetalert2'
import { FaStethoscope } from "react-icons/fa6";
import { MdOutlineMailOutline } from "react-icons/md";
import AdminPanel from '../adminPanel/AdminPanel';
import { Link } from 'react-router-dom';


const ViewProfile = () => {
  const [profiledata, setProfiledata] = useState(null)

  const getdoctorprofile = async () => {
    try {

      const profileresponse = await axios.post("/Dental/doctor/getdoctprofile", {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      },

        {
          params: {
            email: localStorage.getItem("email")
          }

        }
      )

      if (profileresponse.data.status === "success") {
        console.log(profileresponse)
        localStorage.setItem("doctorid", profileresponse.data.data._id)
        setProfiledata(profileresponse.data.data)

      }
      else {
        Swal.fire({
          icon: "error",
          title: "Oops...",
          text: profileresponse.data.message,

        });
      }


    } catch (error) {
      console.log("error", error)

    }

  }

  useEffect(() => {
    getdoctorprofile()

  }, [])



  return (
    <AdminPanel>
      <div className="container bg-white p-5 border rounded-[10px]">
        {/* Profile Section */}
        <div className="profile-section">
          <div className="imageDiv">
            <img
              src={profiledata?.doctorimg || "default-profile.jpg"}
              alt="Profile Picture"
              className="profile-image"
            />
          </div>
          <div className="profile-details font-bold">
            <h2 className='flex items-center gap-2 justify-center'><FaStethoscope />
              {`Dr ${profiledata?.username}`}</h2>
            <h3>{profiledata?.specialization}</h3>
            <h4>{profiledata?.degree}</h4>

          </div>
        </div>
        {/* About Section */}
        <div className="about-section">
          <div class="flex1">


            <h5 className='flex items-center font-bold gap-2 justify-'><MdOutlineMailOutline />Email</h5>
            <p>{profiledata?.email}</p>
          </div>
          <div >
            <h5 className='font-bold'>Phone</h5>
            <p>{profiledata?.mobileno}</p>
          </div>

          <div className=''>
            <h5 className='font-bold'>Age</h5>
            <p>
              {profiledata?.doctorage}
            </p>
          </div>
          <div class="flex1">
            <h5 className='font-bold'>Gender</h5>
            <p>
              {profiledata?.gender}
            </p>
          </div>
          <div class="flex1">
            <h5 className='font-bold'>License No.</h5>
            <p>
              {profiledata?.licenseNo}
            </p>
          </div>
          <div class="flex1">
            <h5 className='font-bold'>Address</h5>
            <p>
              {profiledata?.address}
            </p>
          </div>
        </div>
        

        <button className='mt-4'>
          <Link to={`/doctor/edit/${localStorage.getItem("doctorid")}`}

          >Update</Link>
        </button>
      </div>
    </AdminPanel>


  )
}

export default ViewProfile;